new Typed('#typed', {
    strings: ['CHOOSE US', ],
    typeSpeed: 60,
    delaySpeed: 150,
    loop: true
});

new Typed('#yped', {
    strings: ['Patner With us', 'Choose  us', 'Our services'],
    typeSpeed: 60,
    delaySpeed: 150,
    loop: true
});