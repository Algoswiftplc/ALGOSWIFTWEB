var typed = new Typed(".multi-text", {
    strings: ["MOBILE APP DEVELOPMENT", "WEBSITE DEVELOPMENT", "INTERNET OF THINGS", "GRAPHIC DESIGN"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
})

var typed = new Typed(".single-text", {
    strings: ["MOBILE APP DEVELOPMENT", "WEBSITE DEVELOPMENT", "INTERNET OF THINGS", "GRAPHIC DESIGN"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
})