new Typed('#typed', {
    strings: ['Innovates', 'Creates', 'Optimizes'],
    typeSpeed: 60,
    delaySpeed: 150,
    loop: true
});